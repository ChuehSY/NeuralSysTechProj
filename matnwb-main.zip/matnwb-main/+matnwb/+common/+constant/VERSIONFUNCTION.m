function constant = VERSIONFUNCTION()
    constant = 'Version';
end