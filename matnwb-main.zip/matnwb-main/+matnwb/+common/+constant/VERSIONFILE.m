function constant = VERSIONFILE()
    constant = [matnwb.common.constant.VERSIONFUNCTION, '.m'];
end