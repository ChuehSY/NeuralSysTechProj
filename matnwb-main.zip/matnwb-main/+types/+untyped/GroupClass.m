classdef GroupClass < handle
    %GROUPCLASS Is a HDF5 Group class
    % Used by MetaClass to identify HDF5 class type.
end

