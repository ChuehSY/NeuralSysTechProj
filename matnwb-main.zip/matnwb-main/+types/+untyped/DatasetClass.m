classdef DatasetClass < handle
    %DATASETCLASS Is a HDF5 dataset class
    % Used by MetaClass to identify HDF5 class type.
end

